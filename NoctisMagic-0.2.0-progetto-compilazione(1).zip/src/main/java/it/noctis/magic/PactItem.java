package it.noctis.magic;
import net.minecraft.world.*;
import net.minecraft.world.item.*;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.Level;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.network.chat.Component;
import java.util.function.Supplier;

/** One craftable seal creates one permanently bonded familiar. */
public class PactItem extends Item {
    private final Supplier<EntityType<Familiar>> type;
    public PactItem(Supplier<EntityType<Familiar>> type){super(new Item.Properties().stacksTo(16));this.type=type;}
    @Override public InteractionResultHolder<ItemStack> use(Level level,Player player,InteractionHand hand){
        ItemStack stack=player.getItemInHand(hand);
        if(level instanceof ServerLevel server){
            Familiar f=type.get().create(server);
            if(f==null)return InteractionResultHolder.fail(stack);
            boolean placed=false;
            for(int i=0;i<8;i++){double a=i*Math.PI/4;f.moveTo(player.getX()+Math.cos(a)*1.5,player.getY(),player.getZ()+Math.sin(a)*1.5,player.getYRot(),0);if(server.noCollision(f)){placed=true;break;}}
            if(!placed){player.displayClientMessage(Component.literal("Serve spazio per evocare il famiglio."),true);return InteractionResultHolder.fail(stack);}
            f.tame(player);f.setHealth(f.getMaxHealth());f.setPersistenceRequired();
            if(!server.addFreshEntity(f))return InteractionResultHolder.fail(stack);
            if(!player.getAbilities().instabuild)stack.shrink(1);
            player.displayClientMessage(Component.literal("Il patto eterno è stato sigillato."),true);
            player.getCooldowns().addCooldown(this,20);
        }
        return InteractionResultHolder.sidedSuccess(stack,level.isClientSide);
    }
}
