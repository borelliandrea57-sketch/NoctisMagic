package it.noctis.magic;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.chat.Component;
import net.minecraft.world.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.*;
import net.minecraft.world.level.Level;

public class Vampire extends Zombie {
    public Vampire(EntityType<? extends Zombie> t,Level l){super(t,l);}
    public static AttributeSupplier.Builder attributes(){return Zombie.createAttributes().add(Attributes.MAX_HEALTH,36).add(Attributes.ATTACK_DAMAGE,7).add(Attributes.MOVEMENT_SPEED,.29);}
    @Override protected boolean convertsInWater(){return false;}
    @Override public boolean doHurtTarget(Entity target){boolean hit=super.doHurtTarget(target);if(hit)heal(2);return hit;}
    public static class Friendly extends Vampire {
        private boolean gifted=false;
        public Friendly(EntityType<? extends Zombie> t,Level l){super(t,l);}
        @Override protected void registerGoals(){goalSelector.addGoal(1,new FloatGoal(this));goalSelector.addGoal(2,new WaterAvoidingRandomStrollGoal(this,1));goalSelector.addGoal(3,new LookAtPlayerGoal(this,Player.class,10));goalSelector.addGoal(4,new RandomLookAroundGoal(this));}
        @Override protected boolean isSunSensitive(){return false;}
        @Override public boolean removeWhenFarAway(double d){return false;}
        @Override public InteractionResult mobInteract(Player p,InteractionHand h){if(!level().isClientSide){ItemStack s=p.getItemInHand(h);if(!gifted){gifted=true;give(p,new ItemStack(Noctis.CIGARETTE.get()));p.sendSystemMessage(Component.literal("Vampiro: Buonasera, viandante. Un piccolo regalo."));}else if(s.is(Items.EMERALD)){if(!p.getAbilities().instabuild)s.shrink(1);give(p,new ItemStack(Noctis.CRYSTAL.get()));p.sendSystemMessage(Component.literal("Vampiro: Un cristallo per la tua magia."));}else p.sendSystemMessage(Component.literal("Vampiro: La notte ci appartiene. Ti scambio un cristallo per uno smeraldo."));}return InteractionResult.sidedSuccess(level().isClientSide);}
        private void give(Player p,ItemStack s){if(!p.getInventory().add(s))p.drop(s,false);}
        @Override public void addAdditionalSaveData(CompoundTag t){super.addAdditionalSaveData(t);t.putBoolean("Gifted",gifted);}
        @Override public void readAdditionalSaveData(CompoundTag t){super.readAdditionalSaveData(t);gifted=t.getBoolean("Gifted");}
    }
}
