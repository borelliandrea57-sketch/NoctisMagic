package it.noctis.magic;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.effect.*;
import net.minecraft.world.level.Level;
import java.util.UUID;

public class Tentacle extends PathfinderMob {
    private int lifetime=160;private UUID owner;
    public Tentacle(EntityType<? extends PathfinderMob> t,Level l){super(t,l);setNoAi(true);setNoGravity(true);}
    public static AttributeSupplier.Builder attributes(){return Mob.createMobAttributes().add(Attributes.MAX_HEALTH,24).add(Attributes.MOVEMENT_SPEED,0).add(Attributes.KNOCKBACK_RESISTANCE,1);}
    public void setOwner(Player p){owner=p.getUUID();}
    @Override public void tick(){super.tick();if(!(level() instanceof ServerLevel l))return;if(--lifetime<=0){discard();return;}if(tickCount%10==0){Entity source=owner==null?null:l.getEntity(owner);for(Monster m:l.getEntitiesOfClass(Monster.class,getBoundingBox().inflate(3),e->!(e instanceof Vampire.Friendly))){m.hurt(source instanceof Player p?p.damageSources().playerAttack(p):damageSources().mobAttack(this),5);m.addEffect(new MobEffectInstance(MobEffects.MOVEMENT_SLOWDOWN,35,3));}l.sendParticles(ParticleTypes.SQUID_INK,getX(),getY()+1,getZ(),8,.4,.8,.4,.05);}}
    @Override public void addAdditionalSaveData(CompoundTag t){super.addAdditionalSaveData(t);t.putInt("Life",lifetime);if(owner!=null)t.putUUID("Owner",owner);}
    @Override public void readAdditionalSaveData(CompoundTag t){super.readAdditionalSaveData(t);lifetime=t.getInt("Life");if(t.hasUUID("Owner"))owner=t.getUUID("Owner");}
}
