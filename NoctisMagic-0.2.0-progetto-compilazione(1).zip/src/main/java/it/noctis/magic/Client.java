package it.noctis.magic;
import com.mojang.blaze3d.platform.InputConstants;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.minecraft.client.*;
import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.client.model.*;
import net.minecraft.client.model.geom.*;
import net.minecraft.client.model.geom.builders.*;
import net.minecraft.client.renderer.entity.*;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.monster.Zombie;
import net.minecraftforge.api.distmarker.Dist;
import net.minecraftforge.client.event.*;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import org.lwjgl.glfw.GLFW;

@Mod.EventBusSubscriber(modid=Noctis.ID,value=Dist.CLIENT,bus=Mod.EventBusSubscriber.Bus.MOD)
public class Client {
    static final KeyMapping MENU=new KeyMapping("key.noctismagic.menu",InputConstants.Type.KEYSYM,GLFW.GLFW_KEY_G,"key.categories.noctismagic");
    static final KeyMapping CAST=new KeyMapping("key.noctismagic.cast",InputConstants.Type.KEYSYM,GLFW.GLFW_KEY_R,"key.categories.noctismagic");
    static int selected=0;
    static final ModelLayerLocation UMBREON=layer("umbreon"),OCTOPUS=layer("octopus"),TENTACLE=layer("tentacle"),IMP=layer("imp"),VAMPIRE=layer("vampire"),FRIENDLY=layer("friendly_vampire");
    static ModelLayerLocation layer(String s){return new ModelLayerLocation(new ResourceLocation(Noctis.ID,s),"main");}
    static ResourceLocation tex(String s){return new ResourceLocation(Noctis.ID,"textures/entity/"+s+".png");}
    @SubscribeEvent public static void keys(RegisterKeyMappingsEvent e){e.register(MENU);e.register(CAST);}
    @SubscribeEvent public static void layers(EntityRenderersEvent.RegisterLayerDefinitions e){e.registerLayerDefinition(UMBREON,()->ShapeModel.mesh(0));e.registerLayerDefinition(OCTOPUS,()->ShapeModel.mesh(1));e.registerLayerDefinition(TENTACLE,()->ShapeModel.mesh(2));e.registerLayerDefinition(IMP,()->ShapeModel.mesh(3));e.registerLayerDefinition(VAMPIRE,()->VampRenderer.mesh(false));e.registerLayerDefinition(FRIENDLY,()->VampRenderer.mesh(true));}
    @SubscribeEvent public static void renderers(EntityRenderersEvent.RegisterRenderers e){e.registerEntityRenderer(Noctis.UMBREON.get(),c->new FamiliarRenderer(c,UMBREON,"umbreon"));e.registerEntityRenderer(Noctis.OCTOPUS.get(),c->new FamiliarRenderer(c,OCTOPUS,"octopus"));e.registerEntityRenderer(Noctis.SHADOW.get(),c->new FamiliarRenderer(c,UMBREON,"shadow"));e.registerEntityRenderer(Noctis.IMP.get(),c->new FamiliarRenderer(c,IMP,"imp"));e.registerEntityRenderer(Noctis.DEVIL.get(),c->new FamiliarRenderer(c,IMP,"devil"));e.registerEntityRenderer(Noctis.NIGHT_FAMILIAR.get(),c->new FamiliarRenderer(c,IMP,"night_familiar"));e.registerEntityRenderer(Noctis.FROST_FAMILIAR.get(),c->new FamiliarRenderer(c,IMP,"frost_familiar"));e.registerEntityRenderer(Noctis.TENTACLE.get(),TentacleRenderer::new);e.registerEntityRenderer(Noctis.VAMPIRE.get(),c->new VampRenderer(c,false));e.registerEntityRenderer(Noctis.FRIENDLY.get(),c->new VampRenderer(c,true));}
    @SubscribeEvent public static void overlay(RegisterGuiOverlaysEvent e){e.registerAboveAll("mana",(gui,g,partial,w,h)->{Minecraft mc=Minecraft.getInstance();if(mc.player==null||mc.options.hideGui||mc.player.isSpectator())return;int x=10,y=h-49,bw=125;int max=Noctis.max(Noctis.View.level);g.fill(x-2,y-2,x+bw+2,y+10,0xFFB18A51);g.fill(x-1,y-1,x+bw+1,y+9,0xFF100D1C);g.fill(x,y,x+bw,y+8,0xFF292043);int filled=Math.min(bw,bw*Noctis.View.mana/max);g.fillGradient(x,y,x+filled,y+8,0xFFCF9AFB,0xFF6944A9);g.fill(x,y+9,x+bw,y+11,0xFF171322);g.fill(x,y+9,x+(Noctis.View.level==10?bw:bw*Noctis.View.xp/Noctis.needed(Noctis.View.level)),y+11,0xFFCC9F62);g.drawString(mc.font,"Mana "+Noctis.View.mana+"/"+max+" | Lv "+Noctis.View.level,x,y-11,0xFFFFFFFF);g.drawString(mc.font,"[R] "+Noctis.Spell.values()[selected].label+"  [G]",x,y+14,0xFFDED0FF);});}
    @Mod.EventBusSubscriber(modid=Noctis.ID,value=Dist.CLIENT,bus=Mod.EventBusSubscriber.Bus.FORGE)
    public static class Input { @SubscribeEvent public static void tick(TickEvent.ClientTickEvent e){if(e.phase!=TickEvent.Phase.END)return;Minecraft mc=Minecraft.getInstance();if(mc.player==null||mc.screen!=null)return;while(MENU.consumeClick())mc.setScreen(new SpellScreen());while(CAST.consumeClick())Noctis.NET.sendToServer(new Noctis.Cast(selected));}}
    static class SpellScreen extends Screen {
        SpellScreen(){super(Component.literal("Grimorio innato"));}
        @Override protected void init(){int x=width/2-110,y=height/2-83;for(Noctis.Spell s:Noctis.Spell.values()){int i=s.ordinal();Button b=Button.builder(Component.literal(s.label+" | Lv "+s.level+" | "+s.cost+" mana"),button->{selected=i;onClose();}).bounds(x+(i%2)*112,y+(i/2)*24,109,22).build(); // compact labels replaced below
            b.setMessage(Component.literal(s.label+" ("+s.cost+")"+(s.level>Noctis.View.level?" Lv"+s.level:"")));b.active=s.level<=Noctis.View.level;addRenderableWidget(b);}}
        @Override public void render(GuiGraphics g,int mx,int my,float pt){renderBackground(g);g.drawCenteredString(font,title,width/2,height/2-111,0xFFE5C8FF);g.drawCenteredString(font,"Livello "+Noctis.View.level+" | XP "+Noctis.View.xp+"/"+Noctis.needed(Noctis.View.level),width/2,height/2-98,0xFFFFFFFF);super.render(g,mx,my,pt);g.drawCenteredString(font,"Seleziona una magia, poi premi R",width/2,height/2+47,0xFFDDDDDD);}
        @Override public boolean isPauseScreen(){return false;}
    }
    static class FamiliarRenderer extends MobRenderer<Familiar,ShapeModel<Familiar>>{private final String texture;FamiliarRenderer(EntityRendererProvider.Context c,ModelLayerLocation l,String texture){super(c,new ShapeModel<>(c.bakeLayer(l),l==OCTOPUS?1:l==IMP?3:0),.45f);this.texture=texture;}@Override public ResourceLocation getTextureLocation(Familiar e){return tex(texture);}}
    static class TentacleRenderer extends MobRenderer<Tentacle,ShapeModel<Tentacle>>{TentacleRenderer(EntityRendererProvider.Context c){super(c,new ShapeModel<>(c.bakeLayer(TENTACLE),2),.25f);}@Override public ResourceLocation getTextureLocation(Tentacle e){return tex("tentacle");}}
    static class VampRenderer extends MobRenderer<Zombie,ZombieModel<Zombie>> {
        private final boolean friendly;
        VampRenderer(EntityRendererProvider.Context c,boolean f){super(c,new ZombieModel<>(c.bakeLayer(f?FRIENDLY:VAMPIRE)),.5f);friendly=f;}
        @Override public ResourceLocation getTextureLocation(Zombie e){return tex(friendly?"friendly_vampire":"vampire");}
        static LayerDefinition mesh(boolean friendly){
            MeshDefinition m=HumanoidModel.createMesh(CubeDeformation.NONE,0);PartDefinition head=m.getRoot().getChild("head");
            if(friendly){
                head.addOrReplaceChild("crown",CubeListBuilder.create().texOffs(64,0).addBox(-4.5f,-8.8f,-4.4f,9,3,9),PartPose.ZERO);
                for(int i=0;i<6;i++){float x=-4.2f+i*1.45f;head.addOrReplaceChild("backcurl"+i,CubeListBuilder.create().texOffs(64,16).addBox(-1.2f,0,-1,3,5,3).texOffs(78,16).addBox(-.9f,4.5f,-1.3f,3,5,3).texOffs(92,16).addBox(-1.3f,9,-1,3,5,3),PartPose.offsetAndRotation(x,-6.8f,4.0f,0,0,(i%2==0?.07f:-.07f)));}
                for(int sign:new int[]{-1,1}){head.addOrReplaceChild("sidecurl"+sign,CubeListBuilder.create().texOffs(64,28).addBox(-1.4f,0,-1.4f,3,5,3).texOffs(78,28).addBox(-1,4.5f,-1.4f,3,5,3).texOffs(92,28).addBox(-1.4f,9,-1,3,4,3),PartPose.offsetAndRotation(sign*4.3f,-6.5f,-1.8f,0,0,sign*.08f));}
                head.addOrReplaceChild("fringe",CubeListBuilder.create().texOffs(64,40).addBox(-4,-8.4f,-4.7f,4,3,2).texOffs(80,40).addBox(0,-8.4f,-4.7f,4,2,2),PartPose.ZERO);
                head.addOrReplaceChild("fangs",CubeListBuilder.create().texOffs(96,40).addBox(-2,-1.8f,-4.05f,1,1.7f,.5f).texOffs(96,40).addBox(1,-1.8f,-4.05f,1,1.7f,.5f),PartPose.ZERO);
            }else{head.addOrReplaceChild("hair",CubeListBuilder.create().texOffs(64,0).addBox(-4.4f,-8.6f,-4.4f,9,3,9).texOffs(64,16).addBox(-4,-6,3,8,6,2),PartPose.ZERO);}
            return LayerDefinition.create(m,128,64);
        }
    }
    static class ShapeModel<T extends Entity> extends EntityModel<T>{
        final ModelPart root;final int kind;ShapeModel(ModelPart r,int k){root=r;kind=k;}
        static LayerDefinition mesh(int k){MeshDefinition mesh=new MeshDefinition();PartDefinition r=mesh.getRoot();
            if(k==0){
                r.addOrReplaceChild("body",CubeListBuilder.create().texOffs(0,0).addBox(-3,-4,-5,6,6,10),PartPose.offset(0,18,0));
                r.addOrReplaceChild("head",CubeListBuilder.create().texOffs(0,24).addBox(-4,-5,-5,8,7,6).texOffs(32,24).addBox(-3,-11,-2,2,7,2).texOffs(32,24).addBox(1,-11,-2,2,7,2),PartPose.offset(0,15,-5));
                r.addOrReplaceChild("tail",CubeListBuilder.create().texOffs(40,0).addBox(-1,-2,0,2,3,8).texOffs(40,16).addBox(-1,-2,7,2,2,3),PartPose.offsetAndRotation(0,17,4,-.55f,0,0));
                for(int i=0;i<4;i++)r.addOrReplaceChild("leg"+i,CubeListBuilder.create().texOffs(0,48).addBox(-1,0,-1,2,5,2),PartPose.offset(i%2==0?-2:2,19,i<2?-3:3));
            }else if(k==1){
                r.addOrReplaceChild("body",CubeListBuilder.create().texOffs(0,0).addBox(-6,-10,-6,12,10,12).texOffs(52,0).addBox(-5,-12,-5,10,3,10),PartPose.offset(0,20,0));
                for(int i=0;i<8;i++){double a=i*Math.PI/4;r.addOrReplaceChild("leg"+i,CubeListBuilder.create().texOffs(0,28).addBox(-1.5f,-1,0,3,3,7).texOffs(24,28).addBox(-1,-1.4f,6,2,2,5),PartPose.offsetAndRotation((float)Math.sin(a)*4,22,(float)Math.cos(a)*4,0,(float)a,0));}
            }else if(k==2){
                r.addOrReplaceChild("body",CubeListBuilder.create().texOffs(0,0).addBox(-4,-12,-4,8,12,8).texOffs(0,24).addBox(-3,-22,-3,6,10,6).texOffs(32,24).addBox(-2,-30,-2,4,8,4).texOffs(52,24).addBox(-2,-33,-1,3,5,2),PartPose.offset(0,24,0));
            }else{
                r.addOrReplaceChild("body",CubeListBuilder.create().texOffs(0,0).addBox(-3,-7,-2,6,7,4),PartPose.offset(0,19,0));
                r.addOrReplaceChild("head",CubeListBuilder.create().texOffs(0,16).addBox(-4,-6,-3,8,6,6).texOffs(32,16).addBox(-4,-9,-1,2,4,2).texOffs(32,16).addBox(2,-9,-1,2,4,2).texOffs(42,16).addBox(-5,-5,0,2,3,2).texOffs(42,16).addBox(3,-5,0,2,3,2),PartPose.offset(0,12,0));
                for(int i=0;i<2;i++){
                    int sign=i==0?-1:1;
                    r.addOrReplaceChild("arm"+i,CubeListBuilder.create().texOffs(0,40).addBox(-1,0,-1,2,6,2),PartPose.offset(sign*4,12,0));
                    r.addOrReplaceChild("leg"+i,CubeListBuilder.create().texOffs(12,40).addBox(-1,0,-1,2,5,2).texOffs(22,40).addBox(-1,4,-2,2,1,3),PartPose.offset(sign*1.7f,19,0));
                    r.addOrReplaceChild("wing"+i,CubeListBuilder.create().texOffs(40,40).addBox(sign<0?-7:0,-4,0,7,8,1).texOffs(60,40).addBox(sign<0?-8:0,-5,0,8,2,1),PartPose.offsetAndRotation(sign*2.7f,13,2,0,sign*.35f,0));
                }
                r.addOrReplaceChild("tail",CubeListBuilder.create().texOffs(80,0).addBox(-1,-1,0,2,2,7).texOffs(80,12).addBox(-1.5f,-1.5f,6,3,3,2),PartPose.offsetAndRotation(0,18,2,-.2f,0,0));
            }
            return LayerDefinition.create(mesh,128,64);
        }
        @Override public void setupAnim(T e,float swing,float amount,float age,float yaw,float pitch){
            if(kind==0){root.getChild("head").yRot=yaw*.01745f;root.getChild("head").xRot=pitch*.01745f;for(int i=0;i<4;i++)root.getChild("leg"+i).xRot=(float)Math.cos(swing*.6662+(i%3==0?0:Math.PI))*amount;root.getChild("tail").yRot=(float)Math.sin(age*.2)*.25f;}
            else if(kind==1){for(int i=0;i<8;i++)root.getChild("leg"+i).xRot=(float)Math.sin(age*.25+i)*(.15f+amount*.35f);}
            else if(kind==3){root.getChild("head").yRot=yaw*.01745f;root.getChild("head").xRot=pitch*.01745f;for(int i=0;i<2;i++){float wave=(float)Math.cos(swing*.6662+i*Math.PI)*amount;root.getChild("leg"+i).xRot=wave;root.getChild("arm"+i).xRot=-wave;root.getChild("wing"+i).yRot=(i==0?-1:1)*(.45f+(float)Math.sin(age*.24f)*.25f);}root.getChild("tail").yRot=(float)Math.sin(age*.15f)*.3f;}
            else root.getChild("body").zRot=(float)Math.sin(age*.18)*.16f;
        }
        @Override public void renderToBuffer(PoseStack p,VertexConsumer v,int light,int overlay,float red,float green,float blue,float alpha){root.render(p,v,light,overlay,red,green,blue,alpha);}
    }
}
