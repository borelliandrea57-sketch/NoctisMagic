package it.noctis.magic;

import net.minecraft.nbt.CompoundTag;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.world.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.ai.attributes.*;
import net.minecraft.world.entity.ai.goal.*;
import net.minecraft.world.entity.ai.goal.target.*;
import net.minecraft.world.entity.animal.*;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.*;
import net.minecraft.world.level.*;
import net.minecraft.core.BlockPos;
import net.minecraft.util.RandomSource;

public class Familiar extends TamableAnimal {
    private int lifetime=-1;
    public Familiar(EntityType<? extends TamableAnimal> type,Level level){super(type,level);}
    public static AttributeSupplier.Builder attributes(double health,double damage){return Mob.createMobAttributes().add(Attributes.MAX_HEALTH,health).add(Attributes.ATTACK_DAMAGE,damage).add(Attributes.MOVEMENT_SPEED,.32).add(Attributes.FOLLOW_RANGE,24).add(Attributes.KNOCKBACK_RESISTANCE,.3);}
    public boolean octopus(){return getType()==Noctis.OCTOPUS.get();}
    public boolean eternal(){return getType()==Noctis.IMP.get()||getType()==Noctis.DEVIL.get()||getType()==Noctis.NIGHT_FAMILIAR.get()||getType()==Noctis.FROST_FAMILIAR.get();}
    @Override public boolean hurt(net.minecraft.world.damagesource.DamageSource source,float damage){return eternal()?false:super.hurt(source,damage);}
    public boolean shadow(){return getType()==Noctis.SHADOW.get();}
    public static boolean canSpawn(EntityType<Familiar> type,ServerLevelAccessor level,MobSpawnType reason,BlockPos pos,RandomSource random){return level.getBlockState(pos.below()).isFaceSturdy(level,pos.below(),net.minecraft.core.Direction.UP)&&level.getRawBrightness(pos,0)>7;}
    @Override protected void registerGoals(){goalSelector.addGoal(1,new FloatGoal(this));goalSelector.addGoal(2,new SitWhenOrderedToGoal(this));goalSelector.addGoal(3,new MeleeAttackGoal(this,1.2,true));goalSelector.addGoal(4,new FollowOwnerGoal(this,1.15,6,2,false));goalSelector.addGoal(5,new WaterAvoidingRandomStrollGoal(this,1));goalSelector.addGoal(6,new LookAtPlayerGoal(this,Player.class,8));goalSelector.addGoal(7,new RandomLookAroundGoal(this));targetSelector.addGoal(1,new OwnerHurtByTargetGoal(this));targetSelector.addGoal(2,new OwnerHurtTargetGoal(this));targetSelector.addGoal(3,new HurtByTargetGoal(this));targetSelector.addGoal(4,new NearestAttackableTargetGoal<Monster>(this,Monster.class,10,true,false,e->isTame()&&!isOrderedToSit()&&!(e instanceof Vampire.Friendly)));}
    @Override public boolean doHurtTarget(Entity e){boolean hit=e.hurt(damageSources().mobAttack(this),(float)getAttributeValue(Attributes.ATTACK_DAMAGE));if(hit&&octopus()&&e instanceof LivingEntity le){le.addEffect(new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.MOVEMENT_SLOWDOWN,60,2));}if(hit&&eternal()&&e instanceof LivingEntity le){
        if(getType()==Noctis.IMP.get())le.setSecondsOnFire(4);
        if(getType()==Noctis.DEVIL.get())le.addEffect(new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.WEAKNESS,100,1));
        if(getType()==Noctis.NIGHT_FAMILIAR.get())le.addEffect(new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.WITHER,80,0));
        if(getType()==Noctis.FROST_FAMILIAR.get())le.addEffect(new net.minecraft.world.effect.MobEffectInstance(net.minecraft.world.effect.MobEffects.MOVEMENT_SLOWDOWN,100,3));
        }return hit;}
    @Override public boolean isFood(ItemStack s){return s.is(Items.COD)||s.is(Items.SALMON);}
    @Override public InteractionResult mobInteract(Player p,InteractionHand h){ItemStack s=p.getItemInHand(h);if(shadow())return InteractionResult.PASS;
        if(!isTame()&&(eternal()?s.is(Items.AMETHYST_SHARD):octopus()?isFood(s):s.is(Items.GLOW_BERRIES))){if(!level().isClientSide){if(!p.getAbilities().instabuild)s.shrink(1);if(eternal()||random.nextInt(3)==0){tame(p);setPersistenceRequired();setHealth(getMaxHealth());level().broadcastEntityEvent(this,(byte)7);}else level().broadcastEntityEvent(this,(byte)6);}return InteractionResult.sidedSuccess(level().isClientSide);}
        if(isTame()&&isOwnedBy(p)){if(!level().isClientSide){if(isFood(s)&&getHealth()<getMaxHealth()){heal(8);if(!p.getAbilities().instabuild)s.shrink(1);}else{setOrderedToSit(!isOrderedToSit());setTarget(null);}}return InteractionResult.sidedSuccess(level().isClientSide);}return super.mobInteract(p,h);}
    @Override public AgeableMob getBreedOffspring(ServerLevel level,AgeableMob partner){return null;}
    @Override public boolean canMate(Animal other){return false;}
    @Override public boolean removeWhenFarAway(double d){return false;}
    public void setLifetime(int n){lifetime=n;}
    @Override public void tick(){super.tick();if(!level().isClientSide){if(eternal()){
        if(getHealth()<getMaxHealth())setHealth(getMaxHealth());clearFire();
        if(getY()<level().getMinBuildHeight()-4){LivingEntity owner=getOwner();if(owner!=null&&owner.level()==level())teleportTo(owner.getX(),owner.getY(),owner.getZ());else teleportTo(getX(),level().getMinBuildHeight()+2,getZ());setDeltaMovement(0,0,0);resetFallDistance();}
        }else if(lifetime>=0&&--lifetime<=0)discard();}}
    @Override public void addAdditionalSaveData(CompoundTag t){super.addAdditionalSaveData(t);t.putInt("Lifetime",lifetime);}
    @Override public void readAdditionalSaveData(CompoundTag t){super.readAdditionalSaveData(t);lifetime=t.contains("Lifetime")?t.getInt("Lifetime"):-1;}
}
