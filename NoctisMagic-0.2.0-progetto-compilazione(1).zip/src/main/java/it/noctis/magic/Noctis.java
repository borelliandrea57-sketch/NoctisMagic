package it.noctis.magic;

import net.minecraft.core.BlockPos;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResultHolder;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.effect.*;
import net.minecraft.world.entity.*;
import net.minecraft.world.entity.monster.Monster;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.entity.projectile.LargeFireball;
import net.minecraft.world.item.*;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.*;
import net.minecraft.world.level.ClipContext;
import net.minecraftforge.common.MinecraftForge;
import net.minecraftforge.common.ForgeSpawnEggItem;
import net.minecraftforge.event.TickEvent;
import net.minecraftforge.event.entity.living.*;
import net.minecraftforge.event.entity.player.PlayerEvent;
import net.minecraftforge.event.entity.SpawnPlacementRegisterEvent;
import net.minecraftforge.event.entity.EntityAttributeCreationEvent;
import net.minecraftforge.event.BuildCreativeModeTabContentsEvent;
import net.minecraftforge.eventbus.api.SubscribeEvent;
import net.minecraftforge.fml.common.Mod;
import net.minecraftforge.fml.javafmlmod.FMLJavaModLoadingContext;
import net.minecraftforge.network.*;
import net.minecraftforge.network.simple.SimpleChannel;
import net.minecraftforge.registries.*;
import java.util.function.Supplier;

@Mod(Noctis.ID)
public class Noctis {
    public static final String ID="noctismagic";
    public static final DeferredRegister<Item> ITEMS=DeferredRegister.create(ForgeRegistries.ITEMS, ID);
    public static final DeferredRegister<EntityType<?>> ENTITIES=DeferredRegister.create(ForgeRegistries.ENTITY_TYPES, ID);
    public static final RegistryObject<EntityType<Familiar>> UMBREON=familiar("umbreon",0.8f,0.8f);
    public static final RegistryObject<EntityType<Familiar>> OCTOPUS=familiar("octopus",1.25f,0.8f);
    public static final RegistryObject<EntityType<Familiar>> SHADOW=familiar("shadow",0.8f,0.8f);
    public static final RegistryObject<EntityType<Familiar>> IMP=familiar("imp",.65f,1.15f);
    public static final RegistryObject<EntityType<Familiar>> DEVIL=familiar("devil",.65f,1.15f);
    public static final RegistryObject<EntityType<Familiar>> NIGHT_FAMILIAR=familiar("night_familiar",.65f,1.15f);
    public static final RegistryObject<EntityType<Familiar>> FROST_FAMILIAR=familiar("frost_familiar",.65f,1.15f);
    public static final RegistryObject<EntityType<Tentacle>> TENTACLE=ENTITIES.register("tentacle",()->EntityType.Builder.<Tentacle>of(Tentacle::new,MobCategory.MISC).sized(.65f,2f).clientTrackingRange(8).build(ID+":tentacle"));
    public static final RegistryObject<EntityType<Vampire>> VAMPIRE=ENTITIES.register("vampire",()->EntityType.Builder.<Vampire>of(Vampire::new,MobCategory.MONSTER).sized(.6f,1.95f).clientTrackingRange(8).build(ID+":vampire"));
    public static final RegistryObject<EntityType<Vampire.Friendly>> FRIENDLY=ENTITIES.register("friendly_vampire",()->EntityType.Builder.<Vampire.Friendly>of(Vampire.Friendly::new,MobCategory.MONSTER).sized(.6f,1.95f).clientTrackingRange(8).build(ID+":friendly_vampire"));
    private static RegistryObject<EntityType<Familiar>> familiar(String name,float w,float h){return ENTITIES.register(name,()->EntityType.Builder.<Familiar>of(Familiar::new,MobCategory.CREATURE).sized(w,h).clientTrackingRange(8).build(ID+":"+name));}
    public static final RegistryObject<Item> CRYSTAL=ITEMS.register("mana_crystal",()->new Item(new Item.Properties()){
        @Override public InteractionResultHolder<ItemStack> use(Level l,Player p,InteractionHand h){ItemStack stack=p.getItemInHand(h); if(p instanceof ServerPlayer sp){gain(sp,70); if(!p.getAbilities().instabuild) stack.shrink(1); sync(sp);}return InteractionResultHolder.sidedSuccess(stack,l.isClientSide);}
    });
    public static final RegistryObject<Item> CIGARETTE=ITEMS.register("cigarette",()->new Item(new Item.Properties()));
    public static final RegistryObject<Item> UMBREON_EGG=ITEMS.register("umbreon_spawn_egg",()->new ForgeSpawnEggItem(UMBREON,0x171923,0xe9c849,new Item.Properties()));
    public static final RegistryObject<Item> OCTOPUS_EGG=ITEMS.register("octopus_spawn_egg",()->new ForgeSpawnEggItem(OCTOPUS,0x643a84,0xefa6ff,new Item.Properties()));
    public static final RegistryObject<Item> VAMPIRE_EGG=ITEMS.register("vampire_spawn_egg",()->new ForgeSpawnEggItem(VAMPIRE,0x352536,0xc32645,new Item.Properties()));
    public static final RegistryObject<Item> FRIENDLY_EGG=ITEMS.register("friendly_vampire_spawn_egg",()->new ForgeSpawnEggItem(FRIENDLY,0x352536,0xa9c7e5,new Item.Properties()));
    public static final RegistryObject<Item> IMP_PACT=ITEMS.register("imp_pact",()->new PactItem(IMP));
    public static final RegistryObject<Item> IMP_EGG=ITEMS.register("imp_spawn_egg",()->new ForgeSpawnEggItem(IMP,0xa34038,0xf5b857,new Item.Properties()));
    public static final RegistryObject<Item> DEVIL_PACT=ITEMS.register("devil_pact",()->new PactItem(DEVIL));
    public static final RegistryObject<Item> DEVIL_EGG=ITEMS.register("devil_spawn_egg",()->new ForgeSpawnEggItem(DEVIL,0x6d1735,0xdca13e,new Item.Properties()));
    public static final RegistryObject<Item> NIGHT_FAMILIAR_PACT=ITEMS.register("night_familiar_pact",()->new PactItem(NIGHT_FAMILIAR));
    public static final RegistryObject<Item> NIGHT_FAMILIAR_EGG=ITEMS.register("night_familiar_spawn_egg",()->new ForgeSpawnEggItem(NIGHT_FAMILIAR,0x251d4c,0xaa80ff,new Item.Properties()));
    public static final RegistryObject<Item> FROST_FAMILIAR_PACT=ITEMS.register("frost_familiar_pact",()->new PactItem(FROST_FAMILIAR));
    public static final RegistryObject<Item> FROST_FAMILIAR_EGG=ITEMS.register("frost_familiar_spawn_egg",()->new ForgeSpawnEggItem(FROST_FAMILIAR,0x427b9e,0xb7fbff,new Item.Properties()));
    public static final SimpleChannel NET=NetworkRegistry.newSimpleChannel(new ResourceLocation(ID,"main"),()->"2","2"::equals,"2"::equals);
    public Noctis(){var bus=FMLJavaModLoadingContext.get().getModEventBus(); ITEMS.register(bus);ENTITIES.register(bus);bus.addListener(this::attributes);bus.addListener(this::placements);bus.addListener(this::tab);MinecraftForge.EVENT_BUS.register(this);
        NET.messageBuilder(Cast.class,0,NetworkDirection.PLAY_TO_SERVER).encoder((m,b)->b.writeVarInt(m.spell)).decoder(b->new Cast(b.readVarInt())).consumerMainThread((m,c)->{ServerPlayer p=c.get().getSender();if(p!=null) cast(p,m.spell);c.get().setPacketHandled(true);}).add();
        NET.messageBuilder(State.class,1,NetworkDirection.PLAY_TO_CLIENT).encoder(State::encode).decoder(State::decode).consumerMainThread((m,c)->{View.mana=m.mana;View.level=m.level;View.xp=m.xp;View.cooldown=m.cooldown;c.get().setPacketHandled(true);}).add();
    }
    private void attributes(EntityAttributeCreationEvent e){e.put(UMBREON.get(),Familiar.attributes(40,7).build());e.put(OCTOPUS.get(),Familiar.attributes(100,19).build());e.put(SHADOW.get(),Familiar.attributes(35,9).build());e.put(IMP.get(),Familiar.attributes(32,8).build());e.put(DEVIL.get(),Familiar.attributes(44,12).build());e.put(NIGHT_FAMILIAR.get(),Familiar.attributes(36,10).build());e.put(FROST_FAMILIAR.get(),Familiar.attributes(38,9).build());e.put(TENTACLE.get(),Tentacle.attributes().build());e.put(VAMPIRE.get(),Vampire.attributes().build());e.put(FRIENDLY.get(),Vampire.attributes().build());}
    private void placements(SpawnPlacementRegisterEvent e){
        e.register(UMBREON.get(),SpawnPlacements.Type.ON_GROUND,net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,Familiar::canSpawn,SpawnPlacementRegisterEvent.Operation.REPLACE);
        e.register(OCTOPUS.get(),SpawnPlacements.Type.ON_GROUND,net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,Familiar::canSpawn,SpawnPlacementRegisterEvent.Operation.REPLACE);
        e.register(VAMPIRE.get(),SpawnPlacements.Type.ON_GROUND,net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,Monster::checkMonsterSpawnRules,SpawnPlacementRegisterEvent.Operation.REPLACE);
        e.register(FRIENDLY.get(),SpawnPlacements.Type.ON_GROUND,net.minecraft.world.level.levelgen.Heightmap.Types.MOTION_BLOCKING_NO_LEAVES,Monster::checkMonsterSpawnRules,SpawnPlacementRegisterEvent.Operation.REPLACE);
    }
    private void tab(BuildCreativeModeTabContentsEvent e){if(e.getTabKey()==CreativeModeTabs.INGREDIENTS){e.accept(CRYSTAL.get());e.accept(CIGARETTE.get());e.accept(IMP_PACT.get());e.accept(DEVIL_PACT.get());e.accept(NIGHT_FAMILIAR_PACT.get());e.accept(FROST_FAMILIAR_PACT.get());}if(e.getTabKey()==CreativeModeTabs.SPAWN_EGGS){e.accept(UMBREON_EGG.get());e.accept(OCTOPUS_EGG.get());e.accept(VAMPIRE_EGG.get());e.accept(FRIENDLY_EGG.get());e.accept(IMP_EGG.get());e.accept(DEVIL_EGG.get());e.accept(NIGHT_FAMILIAR_EGG.get());e.accept(FROST_FAMILIAR_EGG.get());}}
    public enum Spell {
        FIRE("Palla di fuoco",1,20),HEAL("Cura",1,18),TENTACLES("Tentacoli",2,35),BLINK("Teletrasporto",3,35),INVISIBLE("Invisibilita",4,40),SUMMON("Evoca ombra",5,55),FLIGHT("Volo",6,65),SHIELD("Invincibilita",8,90),STORM("Tempesta oscura",10,120);
        public final String label;public final int level,cost;Spell(String label,int level,int cost){this.label=label;this.level=level;this.cost=cost;}
    }
    public static class View {public static int mana=100,level=1,xp=0,cooldown=0;}
    public record Cast(int spell){}
    public record State(int mana,int level,int xp,int cooldown){void encode(FriendlyByteBuf b){b.writeVarInt(mana);b.writeVarInt(level);b.writeVarInt(xp);b.writeVarInt(cooldown);}static State decode(FriendlyByteBuf b){return new State(b.readVarInt(),b.readVarInt(),b.readVarInt(),b.readVarInt());}}
    static CompoundTag data(Player p){CompoundTag all=p.getPersistentData();if(!all.contains(ID)){CompoundTag d=new CompoundTag();d.putInt("level",1);d.putInt("mana",100);all.put(ID,d);}return all.getCompound(ID);}
    public static int max(int level){return 100+30*(level-1);}
    public static int needed(int level){return 80*level;}
    static void sync(ServerPlayer p){CompoundTag d=data(p);NET.send(PacketDistributor.PLAYER.with(()->p),new State(d.getInt("mana"),d.getInt("level"),d.getInt("xp"),d.getInt("cooldown")));}
    static void gain(ServerPlayer p,int amount){CompoundTag d=data(p);int level=d.getInt("level"),xp=d.getInt("xp")+amount;while(level<10&&xp>=needed(level)){xp-=needed(level++);d.putInt("mana",max(level));p.sendSystemMessage(Component.literal("Livello magico raggiunto: "+level));}d.putInt("level",level);d.putInt("xp",level==10?0:xp);sync(p);}
    @SubscribeEvent public void login(PlayerEvent.PlayerLoggedInEvent e){if(e.getEntity() instanceof ServerPlayer p){stopFlight(p);sync(p);}}
    @SubscribeEvent public void respawn(PlayerEvent.PlayerRespawnEvent e){if(e.getEntity() instanceof ServerPlayer p)sync(p);}
    @SubscribeEvent public void clone(PlayerEvent.Clone e){if(e.getOriginal().getPersistentData().contains(ID)){CompoundTag copy=data(e.getOriginal()).copy();copy.putInt("flight",0);copy.putInt("shield",0);copy.putInt("cooldown",0);e.getEntity().getPersistentData().put(ID,copy);}}
    @SubscribeEvent public void death(LivingDeathEvent e){if(e.getEntity() instanceof ServerPlayer p)stopFlight(p);if(e.getEntity() instanceof Monster && !(e.getEntity() instanceof Vampire.Friendly)){Entity killer=e.getSource().getEntity();if(killer instanceof ServerPlayer p)gain(p,e.getEntity() instanceof Vampire?35:12);else if(killer instanceof Familiar f && f.getOwner() instanceof ServerPlayer p)gain(p,e.getEntity() instanceof Vampire?35:12);}}
    @SubscribeEvent public void logout(PlayerEvent.PlayerLoggedOutEvent e){if(e.getEntity() instanceof ServerPlayer p)stopFlight(p);}
    @SubscribeEvent public void craft(PlayerEvent.ItemCraftedEvent e){if(e.getEntity() instanceof ServerPlayer p&&e.getCrafting().is(CRYSTAL.get()))gain(p,12);}
    static void stopFlight(ServerPlayer p){CompoundTag d=data(p);if(d.getBoolean("grantedFlight")&&!p.isCreative()&&!p.isSpectator()){p.getAbilities().mayfly=false;p.getAbilities().flying=false;p.onUpdateAbilities();}d.putBoolean("grantedFlight",false);d.putInt("flight",0);}
    @SubscribeEvent public void tick(TickEvent.PlayerTickEvent e){if(e.phase!=TickEvent.Phase.END||!(e.player instanceof ServerPlayer p))return;CompoundTag d=data(p);for(String k:new String[]{"cooldown","shield","flight"})if(d.getInt(k)>0)d.putInt(k,d.getInt(k)-1);if(d.getInt("flight")==0&&d.getBoolean("grantedFlight"))stopFlight(p);if(p.tickCount%10==0){d.putInt("mana",Math.min(max(d.getInt("level")),d.getInt("mana")+2+d.getInt("level")/3));sync(p);}}
    @SubscribeEvent public void invincible(LivingAttackEvent e){if(e.getEntity() instanceof ServerPlayer p&&data(p).getInt("shield")>0&&!e.getSource().is(net.minecraft.tags.DamageTypeTags.BYPASSES_INVULNERABILITY))e.setCanceled(true);}
    static void tell(ServerPlayer p,String s){p.displayClientMessage(Component.literal(s),true);}
    static Vec3 target(ServerPlayer p,double distance){Vec3 start=p.getEyePosition(),end=start.add(p.getLookAngle().scale(distance));return p.level().clip(new ClipContext(start,end,ClipContext.Block.COLLIDER,ClipContext.Fluid.NONE,p)).getLocation();}
    static void cast(ServerPlayer p,int id){if(id<0||id>=Spell.values().length||!p.isAlive()||p.isSpectator())return;Spell s=Spell.values()[id];CompoundTag d=data(p);if(d.getInt("level")<s.level){tell(p,"Richiede livello "+s.level);return;}if(d.getInt("cooldown")>0)return;if(d.getInt("mana")<s.cost){tell(p,"Mana insufficiente");return;}ServerLevel l=p.serverLevel();Vec3 look=p.getLookAngle();
        switch(s){
            case FIRE -> {LargeFireball fire=new LargeFireball(l,p,look.x,look.y,look.z,1);fire.setPos(p.getEyePosition().add(look.scale(1.4)));l.addFreshEntity(fire);}
            case HEAL -> {p.heal(8);p.removeEffect(MobEffects.POISON);}
            case TENTACLES -> {Vec3 t=target(p,12);for(int i=0;i<3;i++){double a=i*Math.PI*2/3;Tentacle tent=TENTACLE.get().create(l);if(tent!=null){tent.moveTo(t.x+Math.cos(a)*1.3,t.y,t.z+Math.sin(a)*1.3);tent.setOwner(p);l.addFreshEntity(tent);}}}
            case BLINK -> {Vec3 start=p.getEyePosition();Vec3 t=target(p,18);double distance=start.distanceTo(t);boolean ok=false;for(double a=Math.max(0,distance-0.8);a>=1;a-=0.5){Vec3 dest=start.add(look.scale(a)).subtract(0,p.getEyeHeight(),0);AABB box=p.getBoundingBox().move(dest.subtract(p.position()));if(l.getWorldBorder().isWithinBounds(BlockPos.containing(dest))&&l.noCollision(p,box)){p.teleportTo(dest.x,dest.y,dest.z);p.resetFallDistance();ok=true;break;}}if(!ok){tell(p,"Nessuna destinazione sicura");return;}}
            case INVISIBLE -> p.addEffect(new MobEffectInstance(MobEffects.INVISIBILITY,20*30,0,false,false));
            case SUMMON -> {for(int i=0;i<2;i++){Familiar f=SHADOW.get().create(l);if(f!=null){f.moveTo(p.getX()+i*1.2,p.getY(),p.getZ()+1);f.tame(p);f.setLifetime(20*60);l.addFreshEntity(f);}}}
            case FLIGHT -> {if(!p.getAbilities().mayfly){d.putBoolean("grantedFlight",true);p.getAbilities().mayfly=true;}d.putInt("flight",20*35);p.getAbilities().flying=true;p.onUpdateAbilities();}
            case SHIELD -> d.putInt("shield",20*15);
            case STORM -> {for(Monster m:l.getEntitiesOfClass(Monster.class,p.getBoundingBox().inflate(10),m->!(m instanceof Vampire.Friendly))){m.hurt(p.damageSources().magic(),24);m.addEffect(new MobEffectInstance(MobEffects.WEAKNESS,160,1));}l.sendParticles(ParticleTypes.DRAGON_BREATH,p.getX(),p.getY()+1,p.getZ(),180,5,1.5,5,.12);}
        }
        d.putInt("mana",d.getInt("mana")-s.cost);d.putInt("cooldown",s==Spell.FIRE?15:25);l.sendParticles(ParticleTypes.PORTAL,p.getX(),p.getY()+1,p.getZ(),20,.5,.6,.5,.1);sync(p);
    }
}
