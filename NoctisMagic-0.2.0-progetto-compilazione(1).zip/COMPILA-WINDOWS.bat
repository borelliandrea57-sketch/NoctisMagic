@echo off
cd /d "%~dp0"
where java >nul 2>&1
if errorlevel 1 (
  echo Installa Java JDK 17 per Windows e configura JAVA_HOME e PATH.
  pause
  exit /b 1
)
call gradlew.bat --no-daemon build
if errorlevel 1 (
  echo Compilazione non riuscita. Copia il messaggio di errore.
  pause
  exit /b 1
)
if not exist "build\libs\noctismagic-0.2.0.jar" (
  echo JAR non trovato.
  pause
  exit /b 1
)
copy /Y "build\libs\noctismagic-0.2.0.jar" "NoctisMagic-0.2.0.jar"
echo JAR creato. Copialo nella cartella mods del profilo Forge 1.20.1.
pause
